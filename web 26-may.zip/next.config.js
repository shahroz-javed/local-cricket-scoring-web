/** @type {import('next').NextConfig} */
const nextConfig = {
    turbopack: {
        root: import.meta.dirname,
    },
    allowedDevOrigins: ['192.168.18.5'],
};

export default nextConfig;
